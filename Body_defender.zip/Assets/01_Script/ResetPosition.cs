using UnityEngine;

public class ResetPosition : MonoBehaviour
{
    // Posici�n a la que volver� el personaje cuando toque el collider con el tag especificado.
    public Vector3 respawnPosition = new Vector3(0, 10, 0);

    // Tag del objeto que sirve como l�mite del mapa
    public string limiteTag = "Limite";

    // M�todo que se ejecuta al entrar en colisi�n con otro objeto
    private void OnTriggerEnter(Collider other)
    {
        // Verifica si el objeto con el que colision� tiene el tag "Limite"
        if (other.CompareTag(limiteTag))
        {
            // Reinicia la posici�n del personaje
            transform.position = respawnPosition;
        }
    }
}
