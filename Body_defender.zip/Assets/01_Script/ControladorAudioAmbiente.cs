using UnityEngine;
using UnityEngine.Audio;

public class ControladorAudioAmbiente : MonoBehaviour
{
    public AudioSource audioAmbiente; // Arrastra el AudioSource de ambiente aqu� desde el Inspector.
    public AudioMixer audioMixer; // Arrastra el AudioMixer desde el Inspector.
    private const string volumenParametro = "VolumenAmbiente";

    void Start()
    {
        // Inicializa el volumen del ambiente al 50%
        SetVolume(0.5f);
    }

    // M�todo para ajustar el volumen del audio ambiente
    public void SetVolume(float volume)
    {
        // Aseg�rate de que el volumen est� entre 0.0 y 1.0
        volume = Mathf.Clamp(volume, 0.0f, 1.0f);

        // Ajustar el volumen del mixer
        audioMixer.SetFloat(volumenParametro, Mathf.Log10(volume) * 20);
    }
}
